<!--  -->
<template>
  <div class='ratings'>
    I am ratings component.
  </div>
</template>

<script>

export default {
  name: 'ratings',
  components: {},
  data () {
    return {

    }
  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='stylus' scoped></style>
