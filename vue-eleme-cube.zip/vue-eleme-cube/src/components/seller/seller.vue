<!--  -->
<template>
  <div class='seller'>
    I am seller component.
  </div>
</template>

<script>

export default {
  name: 'seller',
  components: {},
  data () {
    return {

    }
  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='stylus' scoped></style>
