import Vue from 'vue'
import HeaderDetail from 'components/header-detail/header-detail'
import {
  createAPI
} from 'cube-ui'

createAPI(Vue, HeaderDetail)
