# vue-eleme-cube

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Run your tests

```
npm run test
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
vue 试炼 level0
vscode settings
2d48f81ef5da8764615a40276371da6c
vue 试炼 level0.1
